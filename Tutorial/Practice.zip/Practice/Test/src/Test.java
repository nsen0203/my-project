import java.util.*;
import java.util.stream.Collectors;

public class Test{
	public static void main(String[] args) {
		
//		Map<Integer, String> map = new HashMap<>();
//		map.put(1, "FirstName");
//		map.put(1, "LastName");
		
		
//		List<String> list = new ArrayList<>();
//		list.add("yes");
//		list.add("no");
//		//list.add("yes");
//		list.add(null);
		
		
//		Integer i =10;
//		Integer j =10;
		//how to compare 
		
		List<String> list = new ArrayList<>();
		
		
		list.stream().filter(i->i.contains("Nikhil")).collect(Collectors.toList());
		
		
	}
}

