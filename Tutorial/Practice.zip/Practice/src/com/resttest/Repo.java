package com.resttest;

public class Repo extends JPARepository<Employee, Integer> {

}
