package com.revision.String;

public class SwapTwoWithTemp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10, b = 20, temp;
		temp = a;
		a = b;
		b = temp;
		System.out.println("a :" + a);
		System.out.println("b :" + b);

	}

}
