package com.revision.java8;

public interface Test {
	
	public int show(int x, int y);

}
