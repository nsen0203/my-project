package com.test;

public class StartingWithOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr={121,111,321,542,161};
		for (int i : arr) {
			System.out.println(String.valueOf(i).startsWith("1"));
		}
		
	}

}
